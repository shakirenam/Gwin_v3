package com.Authentication1.Authenticator1.repository;

import com.Authentication1.Authenticator1.model.ServiceRequest;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceRequestRepository extends MongoRepository<ServiceRequest, String> {
    // Fetch service requests by the email of the requestor
    List<ServiceRequest> findByRequestorEmail(String requestorEmail);

    // Fetch service requests by the email of the person who claimed the service request
    List<ServiceRequest> findByClaimedByEmail(String claimedByEmail);

    List<ServiceRequest> findByStatus(String status);
}
