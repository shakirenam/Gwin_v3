package com.Authentication1.Authenticator1.controller;

import com.Authentication1.Authenticator1.model.ActorAction;
import com.Authentication1.Authenticator1.model.ServiceRequest;
import com.Authentication1.Authenticator1.service.ServiceRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/serviceRequests")
public class ServiceRequestController {
    @Autowired
    private ServiceRequestService service;

    // Inner DTO class for the request body
    public static class ServiceRequestUpdateDTO {
        private String claimedByEmail;
        private String status;

        public String getClaimedByEmail() {
            return claimedByEmail;
        }

        public void setClaimedByEmail(String claimedByEmail) {
            this.claimedByEmail = claimedByEmail;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }

    @PostMapping("/insert")
    public ServiceRequest createServiceRequest(@RequestBody ServiceRequest serviceRequest) {
        return service.createOrUpdateServiceRequest(serviceRequest);
    }



    @GetMapping("/all")
    public List<ServiceRequest> getAllServiceRequests() {
        return service.getAllServiceRequests();
    }

    // New endpoint to get service requests by email
    @GetMapping("/by-requestor-email")
    public List<ServiceRequest> getServiceRequestsByRequestorEmail(@RequestParam String email) {
        return service.getServiceRequestsByRequestorEmail(email);
    }


    @GetMapping("/by-claimed-by-email")
    public List<ServiceRequest> getServiceRequestsByClaimedByEmail(@RequestParam String email) {
        return service.getServiceRequestsByClaimedByEmail(email);
    }

    @GetMapping("/{id}")
    public ServiceRequest getServiceRequest(@PathVariable String id) {
        return service.getServiceRequest(id).orElseThrow(() -> new RuntimeException("ServiceRequest not found"));
    }

    @PutMapping("/{id}/status")
    public ServiceRequest updateServiceRequestStatus(@PathVariable String id, @RequestBody String status) {
        return service.updateStatus(id, status);
    }

    @PutMapping("/{id}/status-claimedBy")
    public ServiceRequest updateStatusAndClaimedBy(@PathVariable String id,
                                                   @RequestBody ServiceRequestUpdateDTO requestBody) {
        return service.updateStatusAndClaimedBy(id, requestBody.getStatus(), requestBody.getClaimedByEmail());
    }

    @GetMapping("/status/{status}")
    public List<ServiceRequest> getServiceRequestsByStatus(@PathVariable String status) {
        return service.findByStatus(status);
    }

    @PostMapping("/{id}/actions")
    public ServiceRequest addActionToServiceRequest(@PathVariable String id, @RequestBody ActorAction action) {
        return service.addActorAction(id, action.getActorEmail(), action.getAction());
    }
}
